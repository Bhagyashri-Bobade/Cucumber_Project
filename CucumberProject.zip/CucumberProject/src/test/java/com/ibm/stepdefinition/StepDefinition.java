package com.ibm.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;

public class StepDefinition {

	WebDriver driver;

	@Before
	public void setenv()
	{
		System.out.println("setenv");
		System.setProperty("webdriver.chrome.driver","C:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("user launches google")
	public void user_launch_google() throws InterruptedException {
		String url = "https://www.google.com/"; 
		driver.get(url);
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@When("user enters text {string} in search box")
	public void user_enters_text_in_search_box(String string) throws InterruptedException {
		driver.findElement(By.name("q")).sendKeys(string + Keys.ENTER);
		Thread.sleep(2000);
	}

	@Then("click on first search result")
	public void click_on_first_search_result(){
		driver.findElement(By.xpath("//*[text()= '7 Science-Based Health Benefits of Selenium - Healthline']")).click();
		System.out.println("click is successful");
	}

	@After
	public void teardown() 
	{
		System.out.println("teardown");
		driver.close();
	}
}
